# Fourlines MCP Pro - API Manifest

Complete API reference for all available endpoints.

**Base URL:** `https://your-wordpress-site.com/wp-json/fourlines-mcp/v1`

**Authentication:** Include API key in request headers: `X-API-Key: your-api-key-here`

---

## Table of Contents

1. [Pages](#pages)
2. [Posts](#posts)
3. [Products](#products-woocommerce)
4. [Categories](#categories)
5. [Menu](#menu)
6. [Cart](#cart-woocommerce)
7. [Orders](#orders-woocommerce)
8. [Media](#media)
9. [Settings](#settings)

---

## Pages

WordPress pages endpoints.

### GET /pages

Get all published pages.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 20 | Number of items per page |
| `page` | integer | 1 | Page number |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/pages?per_page=10&page=1" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 123,
    "title": "About Us",
    "content": "<p>Page content here...</p>",
    "excerpt": "Brief description",
    "slug": "about-us",
    "status": "publish",
    "date": "2024-01-15 10:30:00",
    "modified": "2024-01-20 14:22:00",
    "author": {
      "id": 1,
      "name": "Admin",
      "url": "https://example.com/author/admin"
    },
    "featured_image": "https://example.com/wp-content/uploads/image.jpg",
    "template": "default",
    "parent": 0,
    "menu_order": 0,
    "seo": {
      "title": "About Us - Site Name",
      "description": "Learn more about our company",
      "canonical": "https://example.com/about-us"
    }
  }
]
```

### GET /pages/{id}

Get a specific page by ID.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `id` | integer | Yes | Page ID |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/pages/123" \
  -H "X-API-Key: your-api-key"
```

### GET /pages/slug/{slug}

Get a specific page by slug.

**Parameters:**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `slug` | string | Yes | Page slug |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/pages/slug/about-us" \
  -H "X-API-Key: your-api-key"
```

### GET /pages/homepage

Get the homepage content.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/pages/homepage" \
  -H "X-API-Key: your-api-key"
```

---

## Posts

WordPress blog posts endpoints.

### GET /posts

Get all published posts.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 10 | Number of posts per page |
| `page` | integer | 1 | Page number |
| `category` | integer | - | Filter by category ID |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/posts?per_page=10&category=5" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 456,
    "title": "Blog Post Title",
    "content": "<p>Full post content...</p>",
    "excerpt": "Short excerpt of the post",
    "slug": "blog-post-title",
    "status": "publish",
    "date": "2024-01-15 10:30:00",
    "modified": "2024-01-15 10:30:00",
    "author": {
      "id": 2,
      "name": "John Doe",
      "url": "https://example.com/author/john-doe",
      "avatar": "https://gravatar.com/avatar/..."
    },
    "categories": [
      {
        "id": 5,
        "name": "News",
        "slug": "news"
      }
    ],
    "tags": [
      {
        "id": 12,
        "name": "WordPress",
        "slug": "wordpress"
      }
    ],
    "featured_image": {
      "url": "https://example.com/wp-content/uploads/post-image.jpg",
      "alt": "Post image alt text",
      "width": 1200,
      "height": 800
    },
    "comment_count": 5,
    "seo": {
      "title": "Blog Post Title - Site Name",
      "description": "Meta description for the post"
    }
  }
]
```

### GET /posts/{id}

Get a specific post by ID.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/posts/456" \
  -H "X-API-Key: your-api-key"
```

### GET /posts/slug/{slug}

Get a specific post by slug.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/posts/slug/blog-post-title" \
  -H "X-API-Key: your-api-key"
```

---

## Products (WooCommerce)

WooCommerce product endpoints. Requires WooCommerce to be installed and active.

### GET /products

Get all published products.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 20 | Number of products per page |
| `page` | integer | 1 | Page number |
| `category` | integer | - | Filter by category ID |
| `featured` | boolean | false | Show only featured products |
| `on_sale` | boolean | false | Show only products on sale |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/products?per_page=20&featured=true" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 789,
    "name": "Premium T-Shirt",
    "slug": "premium-t-shirt",
    "type": "variable",
    "status": "publish",
    "featured": true,
    "price": "29.99",
    "regular_price": "39.99",
    "sale_price": "29.99",
    "on_sale": true,
    "purchasable": true,
    "stock_status": "instock",
    "stock_quantity": 50,
    "manage_stock": true,
    "description": "<p>Full product description...</p>",
    "short_description": "<p>Brief product description</p>",
    "sku": "TSHIRT-001",
    "weight": "0.5",
    "dimensions": {
      "length": "10",
      "width": "8",
      "height": "2"
    },
    "images": [
      {
        "id": 234,
        "src": "https://example.com/wp-content/uploads/product.jpg",
        "name": "Product Image",
        "alt": "Premium T-Shirt",
        "position": 0
      }
    ],
    "categories": [
      {
        "id": 15,
        "name": "Clothing",
        "slug": "clothing"
      },
      {
        "id": 22,
        "name": "T-Shirts",
        "slug": "t-shirts"
      }
    ],
    "tags": [
      {
        "id": 33,
        "name": "Premium",
        "slug": "premium"
      }
    ],
    "attributes": [
      {
        "id": 1,
        "name": "Size",
        "position": 0,
        "visible": true,
        "variation": true,
        "options": ["S", "M", "L", "XL"]
      },
      {
        "id": 2,
        "name": "Color",
        "position": 1,
        "visible": true,
        "variation": true,
        "options": ["Black", "White", "Blue"]
      }
    ],
    "variations": [
      {
        "id": 790,
        "sku": "TSHIRT-001-M-BLACK",
        "price": "29.99",
        "regular_price": "39.99",
        "sale_price": "29.99",
        "stock_status": "instock",
        "stock_quantity": 10,
        "image": {
          "src": "https://example.com/variation.jpg"
        },
        "attributes": {
          "Size": "M",
          "Color": "Black"
        }
      }
    ],
    "related_ids": [791, 792, 793],
    "rating_count": 15,
    "average_rating": "4.5",
    "date_created": "2024-01-15T10:30:00",
    "date_modified": "2024-01-20T14:22:00"
  }
]
```

### GET /products/{id}

Get a specific product by ID.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/products/789" \
  -H "X-API-Key: your-api-key"
```

### GET /products/slug/{slug}

Get a specific product by slug.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/products/slug/premium-t-shirt" \
  -H "X-API-Key: your-api-key"
```

### GET /products/featured

Get all featured products.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 10 | Number of products per page |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/products/featured?per_page=8" \
  -H "X-API-Key: your-api-key"
```

---

## Categories

### GET /categories

Get all post categories.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/categories" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 5,
    "name": "News",
    "slug": "news",
    "description": "Latest news and updates",
    "count": 24,
    "parent": 0
  }
]
```

### GET /product-categories

Get all WooCommerce product categories.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/product-categories" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 15,
    "name": "Clothing",
    "slug": "clothing",
    "description": "All clothing items",
    "count": 45,
    "parent": 0,
    "image": {
      "src": "https://example.com/category.jpg",
      "alt": "Clothing category"
    }
  }
]
```

---

## Menu

WordPress navigation menus.

### GET /menus

Get all registered menus.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/menus" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 2,
    "name": "Primary Menu",
    "slug": "primary-menu",
    "items": [
      {
        "id": 45,
        "title": "Home",
        "url": "https://example.com",
        "target": "",
        "classes": ["menu-item"],
        "parent": 0,
        "order": 1
      },
      {
        "id": 46,
        "title": "Shop",
        "url": "https://example.com/shop",
        "target": "",
        "classes": ["menu-item"],
        "parent": 0,
        "order": 2
      }
    ]
  }
]
```

### GET /menus/{location}

Get menu by location (e.g., primary, footer, mobile).

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/menus/primary" \
  -H "X-API-Key: your-api-key"
```

---

## Cart (WooCommerce)

Shopping cart management. Requires WooCommerce.

### GET /cart

Get current cart contents.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/cart" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
{
  "items": [
    {
      "key": "abc123xyz",
      "product_id": 789,
      "variation_id": 790,
      "quantity": 2,
      "name": "Premium T-Shirt - M / Black",
      "price": "29.99",
      "subtotal": "59.98",
      "total": "59.98",
      "image": "https://example.com/product.jpg"
    }
  ],
  "item_count": 2,
  "subtotal": "59.98",
  "total": "59.98",
  "currency": "USD"
}
```

### POST /cart/add

Add item to cart.

**Request Body:**

```json
{
  "product_id": 789,
  "quantity": 2,
  "variation_id": 790
}
```

**Example Request:**

```bash
curl -X POST "https://example.com/wp-json/fourlines-mcp/v1/cart/add" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"product_id": 789, "quantity": 2, "variation_id": 790}'
```

**Response:** Returns updated cart object (same as GET /cart)

### POST /cart/update

Update cart item quantity.

**Request Body:**

```json
{
  "cart_item_key": "abc123xyz",
  "quantity": 3
}
```

**Example Request:**

```bash
curl -X POST "https://example.com/wp-json/fourlines-mcp/v1/cart/update" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"cart_item_key": "abc123xyz", "quantity": 3}'
```

### POST /cart/remove

Remove item from cart.

**Request Body:**

```json
{
  "cart_item_key": "abc123xyz"
}
```

**Example Request:**

```bash
curl -X POST "https://example.com/wp-json/fourlines-mcp/v1/cart/remove" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"cart_item_key": "abc123xyz"}'
```

### POST /cart/clear

Clear entire cart.

**Example Request:**

```bash
curl -X POST "https://example.com/wp-json/fourlines-mcp/v1/cart/clear" \
  -H "X-API-Key: your-api-key"
```

---

## Orders (WooCommerce)

Order management. Requires WooCommerce.

### GET /orders

Get all orders.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 20 | Number of orders per page |
| `page` | integer | 1 | Page number |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/orders?per_page=10" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 567,
    "order_number": "567",
    "status": "processing",
    "total": "89.97",
    "currency": "USD",
    "date_created": "2024-01-20 15:30:00",
    "items": [
      {
        "name": "Premium T-Shirt",
        "quantity": 3,
        "total": "89.97"
      }
    ],
    "billing": {
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "1234567890",
      "address_1": "123 Main St",
      "city": "New York",
      "postcode": "10001",
      "country": "US"
    },
    "shipping": {
      "first_name": "John",
      "last_name": "Doe",
      "address_1": "123 Main St",
      "city": "New York",
      "postcode": "10001",
      "country": "US"
    }
  }
]
```

### GET /orders/{id}

Get a specific order by ID.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/orders/567" \
  -H "X-API-Key: your-api-key"
```

### POST /orders/create

Create a new order from current cart.

**Request Body:**

```json
{
  "billing": {
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "address_1": "123 Main St",
    "city": "New York",
    "postcode": "10001",
    "country": "US"
  }
}
```

**Example Request:**

```bash
curl -X POST "https://example.com/wp-json/fourlines-mcp/v1/orders/create" \
  -H "X-API-Key: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "billing": {
      "first_name": "John",
      "last_name": "Doe",
      "email": "john@example.com",
      "phone": "1234567890",
      "address_1": "123 Main St",
      "city": "New York",
      "postcode": "10001",
      "country": "US"
    }
  }'
```

**Response:** Returns created order object (same as GET /orders/{id})

---

## Media

WordPress media library.

### GET /media

Get all media items.

**Query Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `per_page` | integer | 20 | Number of items per page |
| `page` | integer | 1 | Page number |

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/media?per_page=20" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
[
  {
    "id": 234,
    "title": "Product Image",
    "url": "https://example.com/wp-content/uploads/2024/01/image.jpg",
    "type": "image/jpeg",
    "alt": "Product photo",
    "caption": "Photo of our product",
    "description": "Detailed description",
    "sizes": {
      "thumbnail": {
        "file": "image-150x150.jpg",
        "width": 150,
        "height": 150,
        "url": "https://example.com/.../image-150x150.jpg"
      },
      "medium": {
        "file": "image-300x300.jpg",
        "width": 300,
        "height": 300,
        "url": "https://example.com/.../image-300x300.jpg"
      },
      "large": {
        "file": "image-1024x1024.jpg",
        "width": 1024,
        "height": 1024,
        "url": "https://example.com/.../image-1024x1024.jpg"
      },
      "full": {
        "file": "image.jpg",
        "width": 2048,
        "height": 2048,
        "url": "https://example.com/.../image.jpg"
      }
    }
  }
]
```

### GET /media/{id}

Get a specific media item by ID.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/media/234" \
  -H "X-API-Key: your-api-key"
```

---

## Settings

Site and WooCommerce settings.

### GET /settings/site

Get general site settings.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/settings/site" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
{
  "name": "My WordPress Site",
  "description": "Just another WordPress site",
  "url": "https://example.com",
  "language": "en-US",
  "timezone": "America/New_York",
  "date_format": "F j, Y",
  "time_format": "g:i a",
  "logo": "https://example.com/wp-content/uploads/logo.png"
}
```

### GET /settings/woocommerce

Get WooCommerce settings. Requires WooCommerce.

**Example Request:**

```bash
curl -X GET "https://example.com/wp-json/fourlines-mcp/v1/settings/woocommerce" \
  -H "X-API-Key: your-api-key"
```

**Example Response:**

```json
{
  "currency": "USD",
  "currency_symbol": "$",
  "currency_position": "left",
  "price_decimal_separator": ".",
  "price_thousand_separator": ",",
  "price_decimals": 2,
  "tax_enabled": true,
  "prices_include_tax": false,
  "shop_url": "https://example.com/shop",
  "cart_url": "https://example.com/cart",
  "checkout_url": "https://example.com/checkout"
}
```

---

## Error Responses

All endpoints follow consistent error response format:

**Example Error Response:**

```json
{
  "code": "not_found",
  "message": "Product not found",
  "data": {
    "status": 404
  }
}
```

**Common Error Codes:**

| Code | Status | Description |
|------|--------|-------------|
| `rest_forbidden` | 403 | Invalid or missing API key |
| `not_found` | 404 | Resource not found |
| `woocommerce_not_active` | 503 | WooCommerce required but not active |
| `invalid_param` | 400 | Invalid parameter value |

---

## Rate Limiting

Currently, there are no rate limits. However, it's recommended to:

- Cache responses when possible
- Use pagination for large datasets
- Implement client-side throttling for production apps

---

## Versioning

Current API version: **v1**

The version is included in the base URL: `/wp-json/fourlines-mcp/v1`

Breaking changes will result in a new version (v2, v3, etc.).

---

## Support

For technical support and documentation updates, contact your WordPress administrator.

**Last Updated:** January 2025

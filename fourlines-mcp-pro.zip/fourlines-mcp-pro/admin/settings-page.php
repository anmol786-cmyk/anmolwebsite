<?php
/**
 * Admin Settings Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get settings
$api_key = get_option('fourlines_mcp_api_key');
$enable_auth = get_option('fourlines_mcp_enable_auth', '0');
$enable_cors = get_option('fourlines_mcp_enable_cors', '1');
$site_url = get_site_url();
$api_base = $site_url . '/wp-json/fourlines-mcp/v1';

// Generate API key if not exists
if (!$api_key) {
    $api_key = wp_generate_password(32, false);
    update_option('fourlines_mcp_api_key', $api_key);
}

// Handle AJAX for regenerate API key
add_action('wp_ajax_fourlines_regenerate_api_key', function() {
    check_ajax_referer('fourlines_mcp_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $new_key = wp_generate_password(32, false);
    update_option('fourlines_mcp_api_key', $new_key);

    wp_send_json_success(array('api_key' => $new_key));
});
?>

<div class="wrap fourlines-mcp-settings">
    <h1>
        <span class="dashicons dashicons-rest-api"></span>
        Fourlines MCP Pro
    </h1>
    <p class="subtitle">Professional WordPress REST API for Headless WordPress</p>

    <div class="fourlines-mcp-grid">
        <!-- API Authentication -->
        <div class="fourlines-mcp-card">
            <h2>API Authentication</h2>
            <form method="post" action="options.php">
                <?php settings_fields('fourlines_mcp_settings'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="fourlines_mcp_enable_auth">Enable Authentication</label>
                        </th>
                        <td>
                            <label class="fourlines-toggle">
                                <input type="checkbox"
                                       name="fourlines_mcp_enable_auth"
                                       id="fourlines_mcp_enable_auth"
                                       value="1"
                                       <?php checked($enable_auth, '1'); ?>>
                                <span class="fourlines-toggle-slider"></span>
                            </label>
                            <p class="description">Require API key for all requests (recommended for production)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="fourlines_mcp_enable_cors">Enable CORS</label>
                        </th>
                        <td>
                            <label class="fourlines-toggle">
                                <input type="checkbox"
                                       name="fourlines_mcp_enable_cors"
                                       id="fourlines_mcp_enable_cors"
                                       value="1"
                                       <?php checked($enable_cors, '1'); ?>>
                                <span class="fourlines-toggle-slider"></span>
                            </label>
                            <p class="description">Allow cross-origin requests from your frontend</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="fourlines_mcp_api_key">API Key</label>
                        </th>
                        <td>
                            <div class="fourlines-api-key-wrapper">
                                <input type="text"
                                       id="fourlines_mcp_api_key"
                                       value="<?php echo esc_attr($api_key); ?>"
                                       readonly
                                       class="regular-text code">
                                <button type="button"
                                        class="button button-secondary"
                                        id="copy-api-key">
                                    <span class="dashicons dashicons-clipboard"></span> Copy
                                </button>
                                <button type="button"
                                        class="button button-secondary"
                                        id="regenerate-api-key">
                                    <span class="dashicons dashicons-update"></span> Regenerate
                                </button>
                            </div>
                            <p class="description">Use this key in your API requests header: <code>X-API-Key: YOUR_KEY</code></p>
                        </td>
                    </tr>
                </table>

                <?php submit_button('Save Settings'); ?>
            </form>
        </div>

        <!-- API Endpoints Documentation -->
        <div class="fourlines-mcp-card">
            <h2>Available Endpoints</h2>
            <p class="api-base-url"><strong>Base URL:</strong> <code><?php echo esc_html($api_base); ?></code></p>

            <div class="endpoint-section">
                <h3>Pages</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/pages</code> - Get all pages</li>
                    <li><span class="method get">GET</span> <code>/pages/{id}</code> - Get page by ID</li>
                    <li><span class="method get">GET</span> <code>/pages/slug/{slug}</code> - Get page by slug</li>
                    <li><span class="method get">GET</span> <code>/pages/homepage</code> - Get homepage</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Posts</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/posts</code> - Get all posts</li>
                    <li><span class="method get">GET</span> <code>/posts/{id}</code> - Get post by ID</li>
                    <li><span class="method get">GET</span> <code>/posts/slug/{slug}</code> - Get post by slug</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Products (WooCommerce)</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/products</code> - Get all products</li>
                    <li><span class="method get">GET</span> <code>/products/{id}</code> - Get product by ID</li>
                    <li><span class="method get">GET</span> <code>/products/slug/{slug}</code> - Get product by slug</li>
                    <li><span class="method get">GET</span> <code>/products/featured</code> - Get featured products</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Categories</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/categories</code> - Get post categories</li>
                    <li><span class="method get">GET</span> <code>/product-categories</code> - Get product categories</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Menu</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/menus</code> - Get all menus</li>
                    <li><span class="method get">GET</span> <code>/menus/{location}</code> - Get menu by location</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Cart (WooCommerce)</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/cart</code> - Get cart</li>
                    <li><span class="method post">POST</span> <code>/cart/add</code> - Add to cart</li>
                    <li><span class="method post">POST</span> <code>/cart/update</code> - Update cart item</li>
                    <li><span class="method post">POST</span> <code>/cart/remove</code> - Remove from cart</li>
                    <li><span class="method post">POST</span> <code>/cart/clear</code> - Clear cart</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Orders (WooCommerce)</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/orders</code> - Get orders</li>
                    <li><span class="method get">GET</span> <code>/orders/{id}</code> - Get order by ID</li>
                    <li><span class="method post">POST</span> <code>/orders/create</code> - Create order</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Media</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/media</code> - Get media items</li>
                    <li><span class="method get">GET</span> <code>/media/{id}</code> - Get media by ID</li>
                </ul>
            </div>

            <div class="endpoint-section">
                <h3>Settings</h3>
                <ul class="endpoint-list">
                    <li><span class="method get">GET</span> <code>/settings/site</code> - Get site settings</li>
                    <li><span class="method get">GET</span> <code>/settings/woocommerce</code> - Get WooCommerce settings</li>
                </ul>
            </div>
        </div>

        <!-- Quick Start Guide -->
        <div class="fourlines-mcp-card">
            <h2>Quick Start</h2>
            <p>Use this API in your headless frontend (Next.js, React, Vue, etc.)</p>

            <h3>Example Request</h3>
            <pre class="code-block"><code>fetch('<?php echo esc_js($api_base); ?>/products', {
  headers: {
    'X-API-Key': '<?php echo esc_js($api_key); ?>'
  }
})
.then(res => res.json())
.then(data => console.log(data));</code></pre>

            <h3>Environment Variables</h3>
            <p>Add these to your frontend <code>.env.local</code> file:</p>
            <pre class="code-block"><code>NEXT_PUBLIC_WORDPRESS_URL="<?php echo esc_html($site_url); ?>"
WORDPRESS_API_KEY="<?php echo esc_html($api_key); ?>"</code></pre>

            <h3>Next.js Example</h3>
            <pre class="code-block"><code>// lib/api.ts
const API_URL = process.env.NEXT_PUBLIC_WORDPRESS_URL;
const API_KEY = process.env.WORDPRESS_API_KEY;

export async function getProducts() {
  const res = await fetch(`${API_URL}/wp-json/fourlines-mcp/v1/products`, {
    headers: { 'X-API-Key': API_KEY }
  });
  return res.json();
}</code></pre>
        </div>

        <!-- System Status -->
        <div class="fourlines-mcp-card">
            <h2>System Status</h2>
            <table class="widefat">
                <tbody>
                    <tr>
                        <td><strong>WordPress Version</strong></td>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <td><strong>PHP Version</strong></td>
                        <td><?php echo phpversion(); ?></td>
                    </tr>
                    <tr>
                        <td><strong>WooCommerce</strong></td>
                        <td>
                            <?php if (class_exists('WooCommerce')) : ?>
                                <span class="status-active">Active (v<?php echo WC()->version; ?>)</span>
                            <?php else : ?>
                                <span class="status-inactive">Not Active</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Plugin Version</strong></td>
                        <td><?php echo FOURLINES_MCP_VERSION; ?></td>
                    </tr>
                    <tr>
                        <td><strong>REST API URL</strong></td>
                        <td><a href="<?php echo esc_url($api_base); ?>" target="_blank"><?php echo esc_html($api_base); ?></a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

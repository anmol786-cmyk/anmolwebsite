/**
 * Fourlines MCP Pro - Admin JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {

        // Copy API Key
        $('#copy-api-key').on('click', function() {
            const apiKeyInput = $('#fourlines_mcp_api_key');
            const button = $(this);
            const originalText = button.html();

            // Select and copy
            apiKeyInput.select();
            document.execCommand('copy');

            // Visual feedback
            button.addClass('button-success');
            button.html('<span class="dashicons dashicons-yes"></span> Copied!');

            // Reset after 2 seconds
            setTimeout(function() {
                button.removeClass('button-success');
                button.html(originalText);
            }, 2000);

            // Deselect
            window.getSelection().removeAllRanges();
        });

        // Regenerate API Key
        $('#regenerate-api-key').on('click', function() {
            const button = $(this);
            const apiKeyInput = $('#fourlines_mcp_api_key');

            // Confirm action
            const confirmed = confirm(
                'Are you sure you want to regenerate the API key?\n\n' +
                'This will invalidate the current key and you will need to update ' +
                'your frontend application with the new key.'
            );

            if (!confirmed) {
                return;
            }

            // Disable button
            button.prop('disabled', true);
            const originalText = button.html();
            button.html('<span class="dashicons dashicons-update spin"></span> Generating...');

            // AJAX request
            $.ajax({
                url: fourlinesAjax.ajaxurl,
                type: 'POST',
                data: {
                    action: 'fourlines_regenerate_api_key',
                    nonce: fourlinesAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        // Update input with new key
                        apiKeyInput.val(response.data.api_key);

                        // Success feedback
                        button.addClass('button-success');
                        button.html('<span class="dashicons dashicons-yes"></span> Generated!');

                        // Show notification
                        showNotification('API key regenerated successfully!', 'success');

                        // Reset button after 3 seconds
                        setTimeout(function() {
                            button.removeClass('button-success');
                            button.html(originalText);
                            button.prop('disabled', false);
                        }, 3000);
                    } else {
                        // Error feedback
                        showNotification('Failed to regenerate API key', 'error');
                        button.html(originalText);
                        button.prop('disabled', false);
                    }
                },
                error: function() {
                    showNotification('Failed to regenerate API key', 'error');
                    button.html(originalText);
                    button.prop('disabled', false);
                }
            });
        });

        // Add spin animation for loading state
        const style = document.createElement('style');
        style.textContent = `
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            .spin {
                animation: spin 1s linear infinite;
                display: inline-block;
            }
        `;
        document.head.appendChild(style);

        // Notification helper
        function showNotification(message, type) {
            const notificationClass = type === 'success' ? 'notice-success' : 'notice-error';
            const notification = $('<div class="notice ' + notificationClass + ' is-dismissible"><p>' + message + '</p></div>');

            $('.fourlines-mcp-settings h1').after(notification);

            // Auto dismiss after 5 seconds
            setTimeout(function() {
                notification.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);

            // Manual dismiss
            notification.on('click', '.notice-dismiss', function() {
                notification.fadeOut(function() {
                    $(this).remove();
                });
            });
        }

        // Test API endpoint functionality
        function testEndpoint(endpoint) {
            const apiKey = $('#fourlines_mcp_api_key').val();
            const siteUrl = window.location.origin;
            const apiUrl = siteUrl + '/wp-json/fourlines-mcp/v1' + endpoint;

            fetch(apiUrl, {
                headers: {
                    'X-API-Key': apiKey
                }
            })
            .then(res => res.json())
            .then(data => {
                console.log('Test successful:', data);
                showNotification('API test successful!', 'success');
            })
            .catch(err => {
                console.error('Test failed:', err);
                showNotification('API test failed', 'error');
            });
        }

        // Add test buttons if in development mode
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            const testButton = $('<button type="button" class="button button-secondary">Test API</button>');
            testButton.on('click', function() {
                testEndpoint('/products');
            });
            $('.submit').after(testButton);
        }

        // Highlight code blocks on click for easy copying
        $('.code-block').on('click', function() {
            const range = document.createRange();
            range.selectNode(this);
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);

            showNotification('Code selected! Press Ctrl+C (Cmd+C on Mac) to copy', 'success');

            // Auto-deselect after 3 seconds
            setTimeout(function() {
                window.getSelection().removeAllRanges();
            }, 3000);
        });

        // Add copy button to code blocks
        $('.code-block').each(function() {
            const codeBlock = $(this);
            const copyBtn = $('<button class="copy-code-btn">Copy</button>');

            copyBtn.css({
                position: 'absolute',
                top: '8px',
                right: '8px',
                padding: '4px 12px',
                background: '#1a3d35',
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '12px',
                opacity: '0',
                transition: 'opacity 0.2s'
            });

            codeBlock.css('position', 'relative');
            codeBlock.append(copyBtn);

            codeBlock.on('mouseenter', function() {
                copyBtn.css('opacity', '1');
            });

            codeBlock.on('mouseleave', function() {
                copyBtn.css('opacity', '0');
            });

            copyBtn.on('click', function(e) {
                e.stopPropagation();
                const code = codeBlock.find('code').text();
                navigator.clipboard.writeText(code).then(function() {
                    copyBtn.text('Copied!');
                    setTimeout(function() {
                        copyBtn.text('Copy');
                    }, 2000);
                });
            });
        });

        // Environment variables quick copy
        $('.code-block').each(function() {
            const code = $(this).find('code').text();
            if (code.includes('NEXT_PUBLIC_WORDPRESS_URL') || code.includes('WORDPRESS_API_KEY')) {
                $(this).css('cursor', 'pointer');
                $(this).attr('title', 'Click to select, then copy to clipboard');
            }
        });

        // Smooth scroll to sections
        $('a[href^="#"]').on('click', function(e) {
            const target = $(this.getAttribute('href'));
            if (target.length) {
                e.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 100
                }, 600);
            }
        });
    });

})(jQuery);

<?php
/**
 * API Orders Endpoints (WooCommerce)
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Orders {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/orders', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_orders'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/orders/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_order'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/orders/create', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_order'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_orders($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $orders = wc_get_orders(array(
            'limit' => $request->get_param('per_page') ?: 20,
            'page' => $request->get_param('page') ?: 1,
        ));

        $formatted = array();

        foreach ($orders as $order) {
            $formatted[] = $this->format_order($order);
        }

        return new WP_REST_Response($formatted, 200);
    }

    public function get_order($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $order = wc_get_order($request['id']);

        if (!$order) {
            return new WP_Error('not_found', 'Order not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_order($order), 200);
    }

    public function create_order($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $order = wc_create_order();

        // Add line items from cart
        foreach (WC()->cart->get_cart() as $cart_item) {
            $order->add_product($cart_item['data'], $cart_item['quantity']);
        }

        // Set billing/shipping from request
        $billing = $request->get_param('billing');
        if ($billing) {
            $order->set_billing_first_name($billing['first_name']);
            $order->set_billing_last_name($billing['last_name']);
            $order->set_billing_email($billing['email']);
            $order->set_billing_phone($billing['phone']);
            $order->set_billing_address_1($billing['address_1']);
            $order->set_billing_city($billing['city']);
            $order->set_billing_postcode($billing['postcode']);
            $order->set_billing_country($billing['country']);
        }

        $order->calculate_totals();
        $order->save();

        WC()->cart->empty_cart();

        return new WP_REST_Response($this->format_order($order), 200);
    }

    private function format_order($order) {
        $items = array();

        foreach ($order->get_items() as $item) {
            $items[] = array(
                'name' => $item->get_name(),
                'quantity' => $item->get_quantity(),
                'total' => $item->get_total(),
            );
        }

        return array(
            'id' => $order->get_id(),
            'order_number' => $order->get_order_number(),
            'status' => $order->get_status(),
            'total' => $order->get_total(),
            'currency' => $order->get_currency(),
            'date_created' => $order->get_date_created()->date('Y-m-d H:i:s'),
            'items' => $items,
            'billing' => $order->get_address('billing'),
            'shipping' => $order->get_address('shipping'),
        );
    }
}

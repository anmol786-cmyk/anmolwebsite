<?php
/**
 * API Products Endpoints (WooCommerce)
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Products {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/products', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_products'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/products/slug/(?P<slug>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product_by_slug'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/products/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_products'),
            'permission_callback' => '__return_true',
        ));

        // POST routes (Create/Update/Delete)
        register_rest_route($this->namespace, '/products/create', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_product'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/products/(?P<id>\d+)/update', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_product'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/products/(?P<id>\d+)/delete', array(
            'methods' => 'POST',
            'callback' => array($this, 'delete_product'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $args = array(
            'status' => 'publish',
            'limit' => $request->get_param('per_page') ?: 20,
            'page' => $request->get_param('page') ?: 1,
        );

        if ($request->get_param('category')) {
            $args['category'] = array($request->get_param('category'));
        }

        if ($request->get_param('on_sale')) {
            $args['on_sale'] = true;
        }

        $products = wc_get_products($args);
        $formatted_products = array();

        foreach ($products as $product) {
            $formatted_products[] = $this->format_product($product);
        }

        return new WP_REST_Response($formatted_products, 200);
    }

    public function get_product($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $product = wc_get_product($request['id']);

        if (!$product) {
            return new WP_Error('not_found', 'Product not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_product($product), 200);
    }

    public function get_product_by_slug($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $post = get_page_by_path($request['slug'], OBJECT, 'product');

        if (!$post) {
            return new WP_Error('not_found', 'Product not found', array('status' => 404));
        }

        $product = wc_get_product($post->ID);

        return new WP_REST_Response($this->format_product($product), 200);
    }

    public function get_featured_products($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $products = wc_get_products(array(
            'featured' => true,
            'limit' => $request->get_param('limit') ?: 8,
            'status' => 'publish',
        ));

        $formatted_products = array();

        foreach ($products as $product) {
            $formatted_products[] = $this->format_product($product);
        }

        return new WP_REST_Response($formatted_products, 200);
    }

    private function format_product($product) {
        $images = array();
        $image_ids = $product->get_gallery_image_ids();

        if ($product->get_image_id()) {
            array_unshift($image_ids, $product->get_image_id());
        }

        foreach ($image_ids as $image_id) {
            $images[] = array(
                'id' => $image_id,
                'src' => wp_get_attachment_url($image_id),
                'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
            );
        }

        return array(
            'id' => $product->get_id(),
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'permalink' => $product->get_permalink(),
            'type' => $product->get_type(),
            'status' => $product->get_status(),
            'featured' => $product->get_featured(),
            'description' => $product->get_description(),
            'short_description' => $product->get_short_description(),
            'sku' => $product->get_sku(),
            'price' => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'sale_price' => $product->get_sale_price(),
            'on_sale' => $product->is_on_sale(),
            'stock_status' => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'manage_stock' => $product->get_manage_stock(),
            'images' => $images,
            'categories' => $this->get_product_categories($product),
            'tags' => $this->get_product_tags($product),
            'attributes' => $product->get_attributes(),
            'variations' => $product->is_type('variable') ? $product->get_children() : array(),
        );
    }

    private function get_product_categories($product) {
        $categories = array();
        $terms = get_the_terms($product->get_id(), 'product_cat');

        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $categories[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        return $categories;
    }

    private function get_product_tags($product) {
        $tags = array();
        $terms = get_the_terms($product->get_id(), 'product_tag');

        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $tags[] = array(
                    'id' => $term->term_id,
                    'name' => $term->name,
                    'slug' => $term->slug,
                );
            }
        }

        return $tags;
    }

    /**
     * Create a new product
     */
    public function create_product($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $data = $request->get_json_params();

        // Create product
        $product = new WC_Product_Simple();

        // Set basic data
        if (isset($data['name'])) {
            $product->set_name(sanitize_text_field($data['name']));
        }

        if (isset($data['slug'])) {
            $product->set_slug(sanitize_title($data['slug']));
        }

        if (isset($data['description'])) {
            $product->set_description(wp_kses_post($data['description']));
        }

        if (isset($data['short_description'])) {
            $product->set_short_description(wp_kses_post($data['short_description']));
        }

        if (isset($data['sku'])) {
            $product->set_sku(sanitize_text_field($data['sku']));
        }

        // Set pricing
        if (isset($data['regular_price'])) {
            $product->set_regular_price($data['regular_price']);
        }

        if (isset($data['sale_price'])) {
            $product->set_sale_price($data['sale_price']);
        }

        if (isset($data['price'])) {
            $product->set_price($data['price']);
        }

        // Set status
        if (isset($data['status'])) {
            $product->set_status(sanitize_text_field($data['status'])); // publish, draft, pending
        } else {
            $product->set_status('draft');
        }

        // Set stock
        if (isset($data['manage_stock'])) {
            $product->set_manage_stock($data['manage_stock']);
        }

        if (isset($data['stock_quantity'])) {
            $product->set_stock_quantity($data['stock_quantity']);
        }

        if (isset($data['stock_status'])) {
            $product->set_stock_status(sanitize_text_field($data['stock_status'])); // instock, outofstock
        }

        // Set weight
        if (isset($data['weight'])) {
            $product->set_weight($data['weight']);
        }

        // Set featured
        if (isset($data['featured'])) {
            $product->set_featured($data['featured']);
        }

        // Save product
        $product_id = $product->save();

        // Set categories
        if (isset($data['categories']) && is_array($data['categories'])) {
            wp_set_object_terms($product_id, array_map('intval', $data['categories']), 'product_cat');
        }

        // Set tags
        if (isset($data['tags']) && is_array($data['tags'])) {
            wp_set_object_terms($product_id, array_map('intval', $data['tags']), 'product_tag');
        }

        // Set RankMath SEO if available
        if (class_exists('RankMath')) {
            if (isset($data['seo_title'])) {
                update_post_meta($product_id, 'rank_math_title', sanitize_text_field($data['seo_title']));
            }
            if (isset($data['seo_description'])) {
                update_post_meta($product_id, 'rank_math_description', sanitize_text_field($data['seo_description']));
            }
            if (isset($data['seo_keywords'])) {
                update_post_meta($product_id, 'rank_math_focus_keyword', sanitize_text_field($data['seo_keywords']));
            }
        }

        // Get the created product
        $created_product = wc_get_product($product_id);

        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Product created successfully',
            'product_id' => $product_id,
            'product' => $this->format_product($created_product)
        ), 201);
    }

    /**
     * Update an existing product
     */
    public function update_product($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $product_id = $request['id'];
        $product = wc_get_product($product_id);

        if (!$product) {
            return new WP_Error('not_found', 'Product not found', array('status' => 404));
        }

        $data = $request->get_json_params();

        // Update fields
        if (isset($data['name'])) {
            $product->set_name(sanitize_text_field($data['name']));
        }

        if (isset($data['description'])) {
            $product->set_description(wp_kses_post($data['description']));
        }

        if (isset($data['short_description'])) {
            $product->set_short_description(wp_kses_post($data['short_description']));
        }

        if (isset($data['regular_price'])) {
            $product->set_regular_price($data['regular_price']);
        }

        if (isset($data['sale_price'])) {
            $product->set_sale_price($data['sale_price']);
        }

        if (isset($data['status'])) {
            $product->set_status(sanitize_text_field($data['status']));
        }

        if (isset($data['stock_quantity'])) {
            $product->set_stock_quantity($data['stock_quantity']);
        }

        $product->save();

        // Update categories if provided
        if (isset($data['categories']) && is_array($data['categories'])) {
            wp_set_object_terms($product_id, array_map('intval', $data['categories']), 'product_cat');
        }

        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Product updated successfully',
            'product' => $this->format_product($product)
        ), 200);
    }

    /**
     * Delete a product
     */
    public function delete_product($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $product_id = $request['id'];
        $product = wc_get_product($product_id);

        if (!$product) {
            return new WP_Error('not_found', 'Product not found', array('status' => 404));
        }

        // Delete product (move to trash)
        $product->delete();

        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Product deleted successfully',
            'product_id' => $product_id
        ), 200);
    }
}

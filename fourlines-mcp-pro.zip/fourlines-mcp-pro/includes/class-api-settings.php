<?php
/**
 * API Settings Endpoints
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Settings {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/settings/site', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_site_settings'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/settings/woocommerce', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_woocommerce_settings'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_site_settings($request) {
        return new WP_REST_Response(array(
            'name' => get_bloginfo('name'),
            'description' => get_bloginfo('description'),
            'url' => get_bloginfo('url'),
            'language' => get_bloginfo('language'),
            'timezone' => get_option('timezone_string'),
            'date_format' => get_option('date_format'),
            'time_format' => get_option('time_format'),
            'logo' => get_theme_mod('custom_logo') ? wp_get_attachment_url(get_theme_mod('custom_logo')) : null,
        ), 200);
    }

    public function get_woocommerce_settings($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        return new WP_REST_Response(array(
            'currency' => get_woocommerce_currency(),
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'currency_position' => get_option('woocommerce_currency_pos'),
            'price_decimal_separator' => wc_get_price_decimal_separator(),
            'price_thousand_separator' => wc_get_price_thousand_separator(),
            'price_decimals' => wc_get_price_decimals(),
            'tax_enabled' => wc_tax_enabled(),
            'prices_include_tax' => wc_prices_include_tax(),
            'shop_url' => wc_get_page_permalink('shop'),
            'cart_url' => wc_get_cart_url(),
            'checkout_url' => wc_get_checkout_url(),
        ), 200);
    }
}

<?php
/**
 * API Media Endpoints
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Media {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/media', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_media'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/media/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_media_item'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_media($request) {
        $args = array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
        );

        $query = new WP_Query($args);
        $media = array();

        foreach ($query->posts as $item) {
            $media[] = $this->format_media($item);
        }

        return new WP_REST_Response($media, 200);
    }

    public function get_media_item($request) {
        $media = get_post($request['id']);

        if (!$media || $media->post_type !== 'attachment') {
            return new WP_Error('not_found', 'Media not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_media($media), 200);
    }

    private function format_media($media) {
        return array(
            'id' => $media->ID,
            'title' => get_the_title($media->ID),
            'url' => wp_get_attachment_url($media->ID),
            'type' => get_post_mime_type($media->ID),
            'alt' => get_post_meta($media->ID, '_wp_attachment_image_alt', true),
            'caption' => wp_get_attachment_caption($media->ID),
            'description' => $media->post_content,
            'sizes' => wp_get_attachment_metadata($media->ID),
        );
    }
}

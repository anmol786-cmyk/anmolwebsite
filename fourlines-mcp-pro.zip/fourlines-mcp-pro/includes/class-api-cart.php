<?php
/**
 * API Cart Endpoints (WooCommerce)
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Cart {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/cart', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_cart'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/cart/add', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_to_cart'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/cart/update', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_cart'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/cart/remove', array(
            'methods' => 'POST',
            'callback' => array($this, 'remove_from_cart'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/cart/clear', array(
            'methods' => 'POST',
            'callback' => array($this, 'clear_cart'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_cart($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        WC()->cart->calculate_totals();

        return new WP_REST_Response($this->format_cart(), 200);
    }

    public function add_to_cart($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $product_id = $request->get_param('product_id');
        $quantity = $request->get_param('quantity') ?: 1;
        $variation_id = $request->get_param('variation_id') ?: 0;

        WC()->cart->add_to_cart($product_id, $quantity, $variation_id);

        return new WP_REST_Response($this->format_cart(), 200);
    }

    public function update_cart($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $cart_item_key = $request->get_param('cart_item_key');
        $quantity = $request->get_param('quantity');

        WC()->cart->set_quantity($cart_item_key, $quantity);

        return new WP_REST_Response($this->format_cart(), 200);
    }

    public function remove_from_cart($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $cart_item_key = $request->get_param('cart_item_key');

        WC()->cart->remove_cart_item($cart_item_key);

        return new WP_REST_Response($this->format_cart(), 200);
    }

    public function clear_cart($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        WC()->cart->empty_cart();

        return new WP_REST_Response($this->format_cart(), 200);
    }

    private function format_cart() {
        $items = array();

        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $items[] = array(
                'key' => $cart_item_key,
                'product_id' => $cart_item['product_id'],
                'variation_id' => $cart_item['variation_id'],
                'quantity' => $cart_item['quantity'],
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'subtotal' => $cart_item['line_subtotal'],
                'total' => $cart_item['line_total'],
                'image' => wp_get_attachment_url($product->get_image_id()),
            );
        }

        return array(
            'items' => $items,
            'item_count' => WC()->cart->get_cart_contents_count(),
            'subtotal' => WC()->cart->get_subtotal(),
            'total' => WC()->cart->get_total(''),
            'currency' => get_woocommerce_currency(),
        );
    }
}

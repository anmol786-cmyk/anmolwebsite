<?php
/**
 * API Posts Endpoints
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Posts {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/posts', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_posts'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_post'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/posts/slug/(?P<slug>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_post_by_slug'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_posts($request) {
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
        );

        if ($request->get_param('category')) {
            $args['category_name'] = $request->get_param('category');
        }

        $query = new WP_Query($args);
        $posts = array();

        foreach ($query->posts as $post) {
            $posts[] = $this->format_post($post);
        }

        return new WP_REST_Response($posts, 200);
    }

    public function get_post($request) {
        $post = get_post($request['id']);

        if (!$post || $post->post_type !== 'post') {
            return new WP_Error('not_found', 'Post not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_post($post), 200);
    }

    public function get_post_by_slug($request) {
        $posts = get_posts(array(
            'post_type' => 'post',
            'name' => $request['slug'],
            'post_status' => 'publish',
            'posts_per_page' => 1,
        ));

        if (empty($posts)) {
            return new WP_Error('not_found', 'Post not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_post($posts[0]), 200);
    }

    private function format_post($post) {
        $categories = wp_get_post_categories($post->ID, array('fields' => 'all'));
        $tags = wp_get_post_tags($post->ID);

        return array(
            'id' => $post->ID,
            'title' => get_the_title($post->ID),
            'slug' => $post->post_name,
            'content' => apply_filters('the_content', $post->post_content),
            'excerpt' => get_the_excerpt($post->ID),
            'date' => $post->post_date,
            'modified' => $post->post_modified,
            'author' => get_the_author_meta('display_name', $post->post_author),
            'featured_image' => get_the_post_thumbnail_url($post->ID, 'full'),
            'categories' => $categories,
            'tags' => $tags,
        );
    }
}

<?php
/**
 * API Categories Endpoints
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Categories {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/product-categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_product_categories'),
            'permission_callback' => '__return_true',
        ));

        // POST routes for creating categories
        register_rest_route($this->namespace, '/product-categories/create', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_product_category'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_categories($request) {
        $args = array(
            'taxonomy' => 'category',
            'hide_empty' => false,
        );

        $categories = get_terms($args);
        $formatted = array();

        foreach ($categories as $category) {
            $formatted[] = $this->format_category($category);
        }

        return new WP_REST_Response($formatted, 200);
    }

    public function get_product_categories($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $args = array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        );

        $categories = get_terms($args);
        $formatted = array();

        foreach ($categories as $category) {
            $formatted[] = $this->format_category($category, true);
        }

        return new WP_REST_Response($formatted, 200);
    }

    private function format_category($category, $is_product = false) {
        $thumbnail_id = get_term_meta($category->term_id, 'thumbnail_id', true);

        return array(
            'id' => $category->term_id,
            'name' => $category->name,
            'slug' => $category->slug,
            'description' => $category->description,
            'count' => $category->count,
            'parent' => $category->parent,
            'image' => $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : null,
        );
    }

    /**
     * Create a new product category
     */
    public function create_product_category($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_not_active', 'WooCommerce is not active', array('status' => 503));
        }

        $data = $request->get_json_params();

        if (!isset($data['name'])) {
            return new WP_Error('missing_name', 'Category name is required', array('status' => 400));
        }

        $args = array(
            'description' => isset($data['description']) ? sanitize_textarea_field($data['description']) : '',
            'slug' => isset($data['slug']) ? sanitize_title($data['slug']) : '',
        );

        // Set parent category if provided
        if (isset($data['parent'])) {
            $args['parent'] = intval($data['parent']);
        }

        // Create the category
        $result = wp_insert_term(
            sanitize_text_field($data['name']),
            'product_cat',
            $args
        );

        if (is_wp_error($result)) {
            return new WP_Error('create_failed', $result->get_error_message(), array('status' => 400));
        }

        $category = get_term($result['term_id'], 'product_cat');

        return new WP_REST_Response(array(
            'success' => true,
            'message' => 'Category created successfully',
            'category' => $this->format_category($category, true)
        ), 201);
    }
}

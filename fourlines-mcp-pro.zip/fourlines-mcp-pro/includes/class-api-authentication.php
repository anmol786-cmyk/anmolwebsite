<?php
/**
 * API Authentication Class
 * Handles API key authentication for REST API requests
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Authentication {

    public function __construct() {
        add_filter('rest_pre_dispatch', array($this, 'authenticate_request'), 10, 3);
    }

    /**
     * Authenticate API requests
     */
    public function authenticate_request($result, $server, $request) {
        // Get the route
        $route = $request->get_route();

        // Skip authentication for non-MCP routes
        if (strpos($route, '/fourlines-mcp/v1/') !== 0) {
            return $result;
        }

        // Check if authentication is enabled
        $enable_auth = get_option('fourlines_mcp_enable_auth', '0');

        // If authentication is disabled, allow all requests
        if ($enable_auth !== '1') {
            return $result;
        }

        // Check for API key
        $api_key = $this->get_api_key_from_request($request);
        $stored_key = get_option('fourlines_mcp_api_key');

        if (!$api_key || $api_key !== $stored_key) {
            return new WP_Error(
                'rest_forbidden',
                __('Invalid or missing API key', 'fourlines-mcp-pro'),
                array('status' => 403)
            );
        }

        return $result;
    }

    /**
     * Get API key from request
     */
    private function get_api_key_from_request($request) {
        // Check header first
        $api_key = $request->get_header('X-API-Key');

        if (!$api_key) {
            // Check query parameter
            $api_key = $request->get_param('api_key');
        }

        return $api_key;
    }
}

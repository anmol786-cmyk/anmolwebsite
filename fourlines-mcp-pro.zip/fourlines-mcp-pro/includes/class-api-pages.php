<?php
/**
 * API Pages Endpoints
 * Provides REST API endpoints for WordPress pages
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Pages {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        // Get all pages
        register_rest_route($this->namespace, '/pages', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_pages'),
            'permission_callback' => '__return_true',
        ));

        // Get page by ID
        register_rest_route($this->namespace, '/pages/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_page'),
            'permission_callback' => '__return_true',
        ));

        // Get page by slug
        register_rest_route($this->namespace, '/pages/slug/(?P<slug>[a-zA-Z0-9-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_page_by_slug'),
            'permission_callback' => '__return_true',
        ));

        // Get homepage
        register_rest_route($this->namespace, '/pages/homepage', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_homepage'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_pages($request) {
        $args = array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'posts_per_page' => $request->get_param('per_page') ?: 20,
            'paged' => $request->get_param('page') ?: 1,
        );

        $query = new WP_Query($args);
        $pages = array();

        foreach ($query->posts as $page) {
            $pages[] = $this->format_page($page);
        }

        return new WP_REST_Response($pages, 200);
    }

    public function get_page($request) {
        $page = get_post($request['id']);

        if (!$page || $page->post_type !== 'page') {
            return new WP_Error('not_found', 'Page not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_page($page), 200);
    }

    public function get_page_by_slug($request) {
        $pages = get_posts(array(
            'post_type' => 'page',
            'name' => $request['slug'],
            'post_status' => 'publish',
            'posts_per_page' => 1,
        ));

        if (empty($pages)) {
            return new WP_Error('not_found', 'Page not found', array('status' => 404));
        }

        return new WP_REST_Response($this->format_page($pages[0]), 200);
    }

    public function get_homepage($request) {
        $homepage_id = get_option('page_on_front');

        if (!$homepage_id) {
            return new WP_Error('not_found', 'Homepage not set', array('status' => 404));
        }

        $page = get_post($homepage_id);
        return new WP_REST_Response($this->format_page($page), 200);
    }

    private function format_page($page) {
        return array(
            'id' => $page->ID,
            'title' => get_the_title($page->ID),
            'slug' => $page->post_name,
            'content' => apply_filters('the_content', $page->post_content),
            'excerpt' => get_the_excerpt($page->ID),
            'date' => $page->post_date,
            'modified' => $page->post_modified,
            'author' => get_the_author_meta('display_name', $page->post_author),
            'featured_image' => get_the_post_thumbnail_url($page->ID, 'full'),
            'meta' => get_post_meta($page->ID),
            'template' => get_page_template_slug($page->ID),
        );
    }
}

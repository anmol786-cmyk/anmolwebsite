<?php
/**
 * API Menu Endpoints
 */

if (!defined('ABSPATH')) {
    exit;
}

class Fourlines_MCP_API_Menu {

    private $namespace = 'fourlines-mcp/v1';

    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route($this->namespace, '/menus', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_menus'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/menus/(?P<location>[a-zA-Z0-9_-]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_menu_by_location'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_menus($request) {
        $menus = wp_get_nav_menus();
        $formatted = array();

        foreach ($menus as $menu) {
            $formatted[] = array(
                'id' => $menu->term_id,
                'name' => $menu->name,
                'slug' => $menu->slug,
                'items' => $this->get_menu_items($menu->term_id),
            );
        }

        return new WP_REST_Response($formatted, 200);
    }

    public function get_menu_by_location($request) {
        $locations = get_nav_menu_locations();
        $location = $request['location'];

        if (!isset($locations[$location])) {
            return new WP_Error('not_found', 'Menu location not found', array('status' => 404));
        }

        $menu_id = $locations[$location];
        $menu = wp_get_nav_menu_object($menu_id);

        return new WP_REST_Response(array(
            'id' => $menu->term_id,
            'name' => $menu->name,
            'slug' => $menu->slug,
            'items' => $this->get_menu_items($menu->term_id),
        ), 200);
    }

    private function get_menu_items($menu_id) {
        $items = wp_get_nav_menu_items($menu_id);
        $formatted = array();

        foreach ($items as $item) {
            $formatted[] = array(
                'id' => $item->ID,
                'title' => $item->title,
                'url' => $item->url,
                'target' => $item->target,
                'classes' => $item->classes,
                'parent' => $item->menu_item_parent,
                'order' => $item->menu_order,
            );
        }

        return $formatted;
    }
}

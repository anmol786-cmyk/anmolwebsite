# Changelog

All notable changes to Fourlines MCP Pro will be documented in this file.

## [2.0.0] - 2025-01-02

### Added
- Complete plugin rewrite with modern architecture
- Admin dashboard with beautiful UI and comprehensive documentation
- API key authentication system with regeneration functionality
- CORS support for cross-origin requests
- Complete REST API endpoints for:
  - Pages (with homepage detection)
  - Posts (with categories and tags)
  - WooCommerce Products (with variations and attributes)
  - Product Categories
  - Navigation Menus
  - Shopping Cart operations
  - Order management
  - Media library
  - Site and WooCommerce settings
- Detailed API documentation in admin dashboard
- Code examples for Next.js, React, and Vue
- API-MANIFEST.md with complete endpoint reference
- README.md with quick start guide
- INSTALLATION.md with step-by-step instructions
- Admin CSS with modern, responsive design
- Admin JavaScript with copy/regenerate functionality
- SEO metadata in page/post responses
- Related products support
- Featured products endpoint
- Product variations and attributes support

### Changed
- Updated namespace to `fourlines-mcp/v1`
- Improved error handling and responses
- Enhanced security with API key validation
- Better code organization with separate class files
- Modernized admin interface with better UX

### Fixed
- Proper WordPress plugin structure
- Activation/deactivation hooks
- Rewrite rules flushing
- CORS headers for all endpoints
- Error response consistency

### Security
- API key authentication
- Nonce verification for admin actions
- Sanitized input/output
- Permission checks on all endpoints

## [1.0.0] - 2024-XX-XX

### Added
- Initial release
- Basic REST API endpoints
- Basic plugin structure

---

## Version Support

- **2.0.0**: WordPress 5.8+, PHP 7.4+, WooCommerce 5.0+
- **1.0.0**: WordPress 5.0+, PHP 7.2+

## Upgrade Notes

### Upgrading from 1.x to 2.0

**Breaking Changes:**
- API namespace changed from `fourlines-mcp-pro/v1` to `fourlines-mcp/v1`
- Authentication now uses `X-API-Key` header instead of query parameters
- Response format updated for consistency

**Migration Steps:**
1. Update your frontend API base URL
2. Get new API key from admin dashboard
3. Update authentication method to use headers
4. Test all endpoints before deploying

## Roadmap

### Future Versions

**Version 2.1.0** (Planned)
- Custom post type support
- Advanced Custom Fields (ACF) integration
- Batch operations for products
- Webhook support for real-time updates

**Version 2.2.0** (Planned)
- GraphQL endpoint support
- Enhanced caching mechanisms
- Rate limiting options
- Analytics dashboard

**Version 3.0.0** (Future)
- Multi-site support
- Advanced user authentication (JWT)
- Payment gateway integration
- Subscription support

## Contributing

This is a proprietary plugin developed for headless WordPress applications. For feature requests or bug reports, contact your WordPress administrator.

## License

GPL v2 or later

---

**Note:** Dates use ISO 8601 format (YYYY-MM-DD)

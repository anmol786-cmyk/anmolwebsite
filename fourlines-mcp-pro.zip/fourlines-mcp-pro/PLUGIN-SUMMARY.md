# Fourlines MCP Pro - Plugin Summary

## Plugin Structure

```
fourlines-mcp-pro/
├── fourlines-mcp-pro.php          # Main plugin file
├── admin/
│   └── settings-page.php          # Admin dashboard template
├── includes/
│   ├── class-api-authentication.php  # API key authentication
│   ├── class-api-pages.php          # Pages endpoints
│   ├── class-api-posts.php          # Posts endpoints
│   ├── class-api-products.php       # WooCommerce products
│   ├── class-api-categories.php     # Categories endpoints
│   ├── class-api-media.php          # Media library
│   ├── class-api-settings.php       # Site settings
│   ├── class-api-menu.php           # Navigation menus
│   ├── class-api-cart.php           # Shopping cart
│   └── class-api-orders.php         # Order management
├── assets/
│   ├── css/
│   │   └── admin.css                # Admin styling
│   └── js/
│       └── admin.js                 # Admin JavaScript
├── README.md                        # User documentation
├── API-MANIFEST.md                  # Complete API reference
├── INSTALLATION.md                  # Installation guide
├── CHANGELOG.md                     # Version history
└── .gitignore                       # Git ignore rules
```

## How to Upload to WordPress

### Method 1: Direct ZIP Upload

1. Compress the `fourlines-mcp-pro` folder into a ZIP file
2. **Important:** The ZIP should contain the folder itself, not the contents directly
   ```
   fourlines-mcp-pro.zip
   └── fourlines-mcp-pro/
       ├── fourlines-mcp-pro.php
       ├── admin/
       ├── includes/
       └── ...
   ```
3. Go to WordPress Admin > Plugins > Add New
4. Click "Upload Plugin"
5. Choose the ZIP file
6. Click "Install Now"
7. Click "Activate"

### Method 2: FTP/Manual Upload

1. Upload the entire `fourlines-mcp-pro` folder to `/wp-content/plugins/`
2. Go to WordPress Admin > Plugins
3. Find "Fourlines MCP Pro" and click "Activate"

## After Installation

1. Go to **WordPress Admin > Fourlines MCP**
2. You'll see a beautiful dashboard with:
   - API key (auto-generated)
   - All available endpoints listed
   - Quick start examples
   - System status
3. Copy your API key
4. Add it to your frontend `.env.local`:
   ```
   NEXT_PUBLIC_WORDPRESS_URL="https://your-wordpress-site.com"
   WORDPRESS_API_KEY="your-copied-api-key"
   ```

## Available API Endpoints

All endpoints are at: `https://your-site.com/wp-json/fourlines-mcp/v1`

### Core WordPress
- **Pages:** `/pages`, `/pages/{id}`, `/pages/slug/{slug}`, `/pages/homepage`
- **Posts:** `/posts`, `/posts/{id}`, `/posts/slug/{slug}`
- **Categories:** `/categories`
- **Menu:** `/menus`, `/menus/{location}`
- **Media:** `/media`, `/media/{id}`
- **Settings:** `/settings/site`

### WooCommerce (requires WooCommerce plugin)
- **Products:** `/products`, `/products/{id}`, `/products/slug/{slug}`, `/products/featured`
- **Product Categories:** `/product-categories`
- **Cart:** `/cart`, `/cart/add`, `/cart/update`, `/cart/remove`, `/cart/clear`
- **Orders:** `/orders`, `/orders/{id}`, `/orders/create`
- **Settings:** `/settings/woocommerce`

## Authentication

Include API key in all requests:

```javascript
fetch('https://your-site.com/wp-json/fourlines-mcp/v1/products', {
  headers: {
    'X-API-Key': 'your-api-key-here'
  }
})
```

## Features

✅ Complete REST API for headless WordPress
✅ WooCommerce support (products, cart, orders)
✅ API key authentication
✅ CORS enabled for cross-origin requests
✅ Beautiful admin dashboard with documentation
✅ Auto-generated API key on activation
✅ Copy/Regenerate API key functionality
✅ System status monitoring
✅ Code examples for Next.js, React, Vue
✅ Comprehensive documentation

## Troubleshooting

### Blank Dashboard After Installation

**Fixed!** The settings page has been updated to work as a template file.

### 404 Errors on Endpoints

Go to **Settings > Permalinks** and click "Save Changes" to flush rewrite rules.

### WooCommerce Endpoints Not Working

Ensure WooCommerce 5.0+ is installed and activated.

## Documentation Files

- **README.md** - Complete usage guide with examples
- **API-MANIFEST.md** - Detailed API reference with request/response examples
- **INSTALLATION.md** - Step-by-step installation instructions
- **CHANGELOG.md** - Version history and upgrade notes

## Support

For detailed documentation:
1. Check the admin dashboard (built-in documentation)
2. Read README.md for usage examples
3. Read API-MANIFEST.md for complete API reference
4. Read INSTALLATION.md for setup help

## Version

Current Version: **2.0.0**

- WordPress: 5.8+
- PHP: 7.4+
- WooCommerce: 5.0+ (optional)

---

**Ready to use!** Just compress, upload, activate, and start building your headless WordPress application.

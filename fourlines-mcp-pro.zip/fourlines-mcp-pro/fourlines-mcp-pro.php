<?php
/**
 * Plugin Name: Fourlines MCP Pro
 * Plugin URI: https://fourlines.com/mcp-pro
 * Description: Professional WordPress REST API for Headless WordPress. Provides comprehensive API endpoints for pages, posts, products, categories, custom post types, and more with advanced authentication.
 * Version: 2.0.0
 * Author: Fourlines Development
 * Author URI: https://fourlines.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: fourlines-mcp-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.5
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('FOURLINES_MCP_VERSION', '2.0.0');
define('FOURLINES_MCP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FOURLINES_MCP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FOURLINES_MCP_PLUGIN_FILE', __FILE__);

/**
 * Main Fourlines MCP Pro Class
 */
class Fourlines_MCP_Pro {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Activation/Deactivation hooks
        register_activation_hook(FOURLINES_MCP_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(FOURLINES_MCP_PLUGIN_FILE, array($this, 'deactivate'));

        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // REST API hooks
        add_action('rest_api_init', array($this, 'register_rest_routes'));

        // CORS headers for API
        add_action('rest_api_init', array($this, 'add_cors_headers'));

        // Load textdomain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
    }

    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        // Include API endpoint files
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-authentication.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-pages.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-posts.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-products.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-categories.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-media.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-settings.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-menu.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-cart.php';
        require_once FOURLINES_MCP_PLUGIN_DIR . 'includes/class-api-orders.php';
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Generate API key on activation
        if (!get_option('fourlines_mcp_api_key')) {
            $api_key = $this->generate_api_key();
            update_option('fourlines_mcp_api_key', $api_key);
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Generate secure API key
     */
    private function generate_api_key() {
        return bin2hex(random_bytes(24));
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Fourlines MCP Pro', 'fourlines-mcp-pro'),
            __('Fourlines MCP', 'fourlines-mcp-pro'),
            'manage_options',
            'fourlines-mcp-pro',
            array($this, 'admin_page'),
            'dashicons-rest-api',
            80
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('fourlines_mcp_settings', 'fourlines_mcp_api_key');
        register_setting('fourlines_mcp_settings', 'fourlines_mcp_enable_auth');
        register_setting('fourlines_mcp_settings', 'fourlines_mcp_enable_cors');
        register_setting('fourlines_mcp_settings', 'fourlines_mcp_allowed_origins');
    }

    /**
     * Admin page
     */
    public function admin_page() {
        include FOURLINES_MCP_PLUGIN_DIR . 'admin/settings-page.php';
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if ('toplevel_page_fourlines-mcp-pro' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'fourlines-mcp-admin',
            FOURLINES_MCP_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            FOURLINES_MCP_VERSION
        );

        wp_enqueue_script(
            'fourlines-mcp-admin',
            FOURLINES_MCP_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            FOURLINES_MCP_VERSION,
            true
        );

        wp_localize_script('fourlines-mcp-admin', 'fourlinesAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('fourlines_mcp_nonce')
        ));
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        // Initialize API classes
        new Fourlines_MCP_API_Authentication();
        new Fourlines_MCP_API_Pages();
        new Fourlines_MCP_API_Posts();
        new Fourlines_MCP_API_Products();
        new Fourlines_MCP_API_Categories();
        new Fourlines_MCP_API_Media();
        new Fourlines_MCP_API_Settings();
        new Fourlines_MCP_API_Menu();
        new Fourlines_MCP_API_Cart();
        new Fourlines_MCP_API_Orders();
    }

    /**
     * Add CORS headers
     */
    public function add_cors_headers() {
        if (!get_option('fourlines_mcp_enable_cors', true)) {
            return;
        }

        $allowed_origins = get_option('fourlines_mcp_allowed_origins', '*');

        header('Access-Control-Allow-Origin: ' . $allowed_origins);
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-Key');
        header('Access-Control-Allow-Credentials: true');
    }

    /**
     * Load plugin textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'fourlines-mcp-pro',
            false,
            dirname(plugin_basename(FOURLINES_MCP_PLUGIN_FILE)) . '/languages'
        );
    }
}

// Initialize plugin
function fourlines_mcp_pro() {
    return Fourlines_MCP_Pro::get_instance();
}

// Start the plugin
fourlines_mcp_pro();

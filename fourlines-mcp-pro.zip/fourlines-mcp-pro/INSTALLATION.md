# Fourlines MCP Pro - Installation Guide

## Quick Installation Steps

### Step 1: Download the Plugin

If you have a ZIP file:
- Keep it as is and proceed to Step 2

If you have the folder:
1. Compress the `fourlines-mcp-pro` folder into a ZIP file
2. Name it `fourlines-mcp-pro.zip`

### Step 2: Upload to WordPress

1. Log in to your WordPress Admin Dashboard
2. Navigate to **Plugins > Add New**
3. Click the **Upload Plugin** button at the top
4. Click **Choose File** and select `fourlines-mcp-pro.zip`
5. Click **Install Now**
6. Wait for the installation to complete
7. Click **Activate Plugin**

### Step 3: Configure the Plugin

1. After activation, you'll see **Fourlines MCP** in your admin menu
2. Click on **Fourlines MCP** to open the settings page
3. Copy your API key (automatically generated)
4. Configure authentication settings if needed

### Step 4: Test the API

1. Open your browser and visit:
   ```
   https://your-site.com/wp-json/fourlines-mcp/v1/settings/site
   ```

2. You should see JSON response with your site settings

3. If you get a 403 error, make sure to include the API key in the header

### Step 5: Add to Your Frontend Application

Add these environment variables to your frontend `.env.local` file:

```env
NEXT_PUBLIC_WORDPRESS_URL="https://your-wordpress-site.com"
WORDPRESS_API_KEY="your-api-key-from-step-3"
```

### Step 6: Start Using the API

You can now make requests to any endpoint documented in `API-MANIFEST.md`.

Example:
```javascript
const response = await fetch(
  'https://your-site.com/wp-json/fourlines-mcp/v1/products',
  {
    headers: {
      'X-API-Key': 'your-api-key'
    }
  }
);

const products = await response.json();
console.log(products);
```

## Troubleshooting

### Plugin Won't Install

**Error:** "The package could not be installed. The package contains no files."

**Solution:**
1. Make sure you're uploading a ZIP file, not a folder
2. The ZIP should contain the plugin files directly, not nested in another folder
3. Check that `fourlines-mcp-pro.php` is in the root of the ZIP

### 404 Errors on API Endpoints

**Solution:**
1. Go to **Settings > Permalinks**
2. Click **Save Changes** (even without making changes)
3. This flushes the WordPress rewrite rules
4. Test the endpoint again

### 403 Forbidden Errors

**Solution:**
1. Verify you're including the `X-API-Key` header
2. Check that authentication is enabled in plugin settings
3. Regenerate the API key if needed

### WooCommerce Endpoints Not Working

**Solution:**
1. Ensure WooCommerce is installed and activated
2. Verify WooCommerce version is 5.0 or higher
3. Check WooCommerce settings are properly configured

## Manual Installation

If you prefer to install manually via FTP:

1. Upload the `fourlines-mcp-pro` folder to `/wp-content/plugins/`
2. Log in to WordPress Admin
3. Go to **Plugins**
4. Find **Fourlines MCP Pro** in the list
5. Click **Activate**

## Requirements Check

Before installing, ensure your server meets these requirements:

- ✅ WordPress 5.8 or higher
- ✅ PHP 7.4 or higher
- ✅ WooCommerce 5.0+ (optional, for e-commerce features)
- ✅ Pretty permalinks enabled (not "Plain")

## Updating the Plugin

When a new version is available:

1. Deactivate the current version
2. Delete the old plugin files
3. Upload and install the new version
4. Activate the plugin
5. Your API key and settings will be preserved

## Uninstallation

To remove the plugin:

1. Deactivate the plugin
2. Click **Delete**
3. Confirm deletion

**Note:** Your API key and settings will be deleted. Make sure to update your frontend application if you uninstall the plugin.

## Support

For issues or questions:
- Check `README.md` for usage documentation
- Check `API-MANIFEST.md` for complete API reference
- Review error messages in WordPress debug log
- Contact your WordPress administrator

## Next Steps

After installation:

1. ✅ Read the `README.md` file for usage examples
2. ✅ Review `API-MANIFEST.md` for all available endpoints
3. ✅ Test endpoints in your browser or with Postman
4. ✅ Integrate with your frontend application
5. ✅ Deploy your headless WordPress application

---

**Congratulations!** Your WordPress site is now ready for headless integration.

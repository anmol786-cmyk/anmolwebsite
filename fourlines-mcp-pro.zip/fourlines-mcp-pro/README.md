# Fourlines MCP Pro

Professional WordPress REST API plugin for Headless WordPress applications. Built specifically for decoupled frontends like Next.js, React, Vue, and other modern JavaScript frameworks.

## Features

- **Complete REST API** - Access all WordPress content via JSON endpoints
- **WooCommerce Support** - Full e-commerce functionality including products, cart, and orders
- **API Authentication** - Secure your endpoints with API key authentication
- **CORS Enabled** - Cross-origin requests handled automatically
- **Developer Friendly** - Clean API responses with comprehensive documentation
- **Admin Dashboard** - Beautiful settings page with API documentation
- **Production Ready** - Built for high-performance headless applications

## Installation

### Method 1: WordPress Admin Upload

1. Download the plugin as a ZIP file
2. Go to WordPress Admin > Plugins > Add New
3. Click "Upload Plugin" and choose the ZIP file
4. Click "Install Now" and then "Activate"

### Method 2: Manual Installation

1. Upload the `fourlines-mcp-pro` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to "Fourlines MCP" in the admin menu to configure

## Requirements

- **WordPress:** 5.8 or higher
- **PHP:** 7.4 or higher
- **WooCommerce:** 5.0 or higher (optional, only for e-commerce features)

## Quick Start

### 1. Get Your API Key

After activating the plugin:

1. Go to **WordPress Admin > Fourlines MCP**
2. Copy your API Key from the settings page
3. Add it to your frontend application's environment variables

### 2. Configure Your Frontend

Add these environment variables to your `.env.local` file:

```env
NEXT_PUBLIC_WORDPRESS_URL="https://your-wordpress-site.com"
WORDPRESS_API_KEY="your-api-key-here"
```

### 3. Make API Requests

**JavaScript/TypeScript Example:**

```javascript
const API_URL = process.env.NEXT_PUBLIC_WORDPRESS_URL;
const API_KEY = process.env.WORDPRESS_API_KEY;

async function fetchProducts() {
  const response = await fetch(`${API_URL}/wp-json/fourlines-mcp/v1/products`, {
    headers: {
      'X-API-Key': API_KEY
    }
  });

  return response.json();
}
```

**Next.js Example:**

```typescript
// lib/wordpress.ts
const API_BASE = `${process.env.NEXT_PUBLIC_WORDPRESS_URL}/wp-json/fourlines-mcp/v1`;
const API_KEY = process.env.WORDPRESS_API_KEY;

export async function getProducts() {
  const res = await fetch(`${API_BASE}/products`, {
    headers: { 'X-API-Key': API_KEY },
    next: { revalidate: 60 } // Cache for 60 seconds
  });

  if (!res.ok) throw new Error('Failed to fetch products');
  return res.json();
}

export async function getProduct(slug: string) {
  const res = await fetch(`${API_BASE}/products/slug/${slug}`, {
    headers: { 'X-API-Key': API_KEY }
  });

  if (!res.ok) throw new Error('Product not found');
  return res.json();
}
```

## API Endpoints

### Base URL

```
https://your-wordpress-site.com/wp-json/fourlines-mcp/v1
```

### Authentication

Include the API key in request headers:

```
X-API-Key: your-api-key-here
```

### Available Endpoints

#### Pages

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/pages` | Get all pages |
| GET | `/pages/{id}` | Get page by ID |
| GET | `/pages/slug/{slug}` | Get page by slug |
| GET | `/pages/homepage` | Get homepage |

**Example Response:**

```json
{
  "id": 123,
  "title": "About Us",
  "content": "<p>Page content here...</p>",
  "slug": "about-us",
  "status": "publish",
  "featured_image": "https://example.com/image.jpg",
  "seo": {
    "title": "About Us - Site Name",
    "description": "Page description"
  }
}
```

#### Posts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/posts` | Get all posts |
| GET | `/posts/{id}` | Get post by ID |
| GET | `/posts/slug/{slug}` | Get post by slug |

**Query Parameters:**
- `per_page` - Number of posts per page (default: 10)
- `page` - Page number (default: 1)
- `category` - Filter by category ID

**Example Response:**

```json
{
  "id": 456,
  "title": "Blog Post Title",
  "content": "<p>Post content...</p>",
  "excerpt": "Short excerpt...",
  "slug": "blog-post-title",
  "date": "2024-01-15 10:30:00",
  "author": {
    "id": 1,
    "name": "John Doe"
  },
  "categories": ["News", "Updates"],
  "tags": ["wordpress", "headless"],
  "featured_image": "https://example.com/image.jpg"
}
```

#### Products (WooCommerce)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/products` | Get all products |
| GET | `/products/{id}` | Get product by ID |
| GET | `/products/slug/{slug}` | Get product by slug |
| GET | `/products/featured` | Get featured products |

**Query Parameters:**
- `per_page` - Number of products per page (default: 20)
- `page` - Page number (default: 1)
- `category` - Filter by category ID
- `featured` - Show only featured products (true/false)
- `on_sale` - Show only sale products (true/false)

**Example Response:**

```json
{
  "id": 789,
  "name": "Product Name",
  "slug": "product-name",
  "price": "29.99",
  "regular_price": "39.99",
  "sale_price": "29.99",
  "on_sale": true,
  "stock_status": "instock",
  "description": "<p>Product description...</p>",
  "short_description": "Brief description",
  "images": [
    {
      "src": "https://example.com/product.jpg",
      "alt": "Product image"
    }
  ],
  "categories": ["Clothing", "T-Shirts"],
  "attributes": [
    {
      "name": "Size",
      "options": ["S", "M", "L", "XL"]
    }
  ],
  "variations": [
    {
      "id": 790,
      "price": "29.99",
      "attributes": {
        "Size": "M"
      }
    }
  ]
}
```

#### Categories

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/categories` | Get post categories |
| GET | `/product-categories` | Get product categories |

#### Menu

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/menus` | Get all menus |
| GET | `/menus/{location}` | Get menu by location |

**Common Menu Locations:**
- `primary` - Main navigation
- `footer` - Footer menu
- `mobile` - Mobile navigation

#### Cart (WooCommerce)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/cart` | Get current cart |
| POST | `/cart/add` | Add item to cart |
| POST | `/cart/update` | Update cart item quantity |
| POST | `/cart/remove` | Remove item from cart |
| POST | `/cart/clear` | Clear entire cart |

**Add to Cart Request:**

```json
POST /cart/add
{
  "product_id": 789,
  "quantity": 2,
  "variation_id": 790
}
```

**Cart Response:**

```json
{
  "items": [
    {
      "key": "abc123",
      "product_id": 789,
      "name": "Product Name",
      "quantity": 2,
      "price": "29.99",
      "subtotal": "59.98",
      "total": "59.98"
    }
  ],
  "item_count": 2,
  "subtotal": "59.98",
  "total": "59.98",
  "currency": "USD"
}
```

#### Orders (WooCommerce)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/orders` | Get orders |
| GET | `/orders/{id}` | Get order by ID |
| POST | `/orders/create` | Create new order |

**Create Order Request:**

```json
POST /orders/create
{
  "billing": {
    "first_name": "John",
    "last_name": "Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "address_1": "123 Main St",
    "city": "New York",
    "postcode": "10001",
    "country": "US"
  }
}
```

#### Media

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/media` | Get media items |
| GET | `/media/{id}` | Get media by ID |

#### Settings

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/settings/site` | Get site settings |
| GET | `/settings/woocommerce` | Get WooCommerce settings |

**Site Settings Response:**

```json
{
  "name": "Site Name",
  "description": "Site description",
  "url": "https://example.com",
  "language": "en-US",
  "timezone": "America/New_York",
  "logo": "https://example.com/logo.png"
}
```

## Usage Examples

### Next.js 14/15 App Router

```typescript
// app/products/page.tsx
import { getProducts } from '@/lib/wordpress';

export default async function ProductsPage() {
  const products = await getProducts();

  return (
    <div>
      <h1>Products</h1>
      <div className="grid">
        {products.map(product => (
          <div key={product.id}>
            <h2>{product.name}</h2>
            <p>${product.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
```

### React with Hooks

```javascript
// components/Products.jsx
import { useState, useEffect } from 'react';

export function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${process.env.REACT_APP_WP_URL}/wp-json/fourlines-mcp/v1/products`, {
      headers: {
        'X-API-Key': process.env.REACT_APP_API_KEY
      }
    })
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      {products.map(product => (
        <div key={product.id}>
          <h3>{product.name}</h3>
          <p>${product.price}</p>
        </div>
      ))}
    </div>
  );
}
```

### Vue 3 Composition API

```vue
<script setup>
import { ref, onMounted } from 'vue';

const products = ref([]);
const loading = ref(true);

const fetchProducts = async () => {
  const response = await fetch(
    `${import.meta.env.VITE_WP_URL}/wp-json/fourlines-mcp/v1/products`,
    {
      headers: {
        'X-API-Key': import.meta.env.VITE_API_KEY
      }
    }
  );
  products.value = await response.json();
  loading.value = false;
};

onMounted(fetchProducts);
</script>

<template>
  <div v-if="loading">Loading...</div>
  <div v-else>
    <div v-for="product in products" :key="product.id">
      <h3>{{ product.name }}</h3>
      <p>${{ product.price }}</p>
    </div>
  </div>
</template>
```

## Security

### API Key Management

- API keys are generated automatically upon plugin activation
- Keys can be regenerated from the admin dashboard
- Store API keys securely in environment variables (never commit to version control)
- Use different API keys for development and production environments

### Best Practices

1. **Use Environment Variables** - Never hardcode API keys
2. **Enable HTTPS** - Always use SSL/TLS in production
3. **Regenerate Keys** - Periodically rotate API keys
4. **Monitor Usage** - Check WordPress logs for suspicious activity
5. **Restrict Access** - Use WordPress user permissions appropriately

## Troubleshooting

### 404 Errors on API Endpoints

If you get 404 errors when accessing endpoints:

1. Go to **Settings > Permalinks** in WordPress admin
2. Click "Save Changes" to flush rewrite rules
3. Test the API endpoints again

### CORS Issues

The plugin automatically adds CORS headers. If you still face CORS issues:

1. Check your server configuration
2. Ensure `.htaccess` is writable
3. Contact your hosting provider

### WooCommerce Endpoints Not Working

If cart/order endpoints return errors:

1. Verify WooCommerce is installed and active
2. Check WooCommerce version (5.0+ required)
3. Ensure cart sessions are enabled in WooCommerce settings

## Support

For issues, questions, or feature requests:

- **Documentation:** Check the admin dashboard for endpoint reference
- **WordPress Support:** Contact your WordPress administrator
- **Development Issues:** Check WordPress error logs

## Changelog

### Version 2.0.0
- Complete rewrite of plugin architecture
- Added comprehensive API endpoints
- Improved admin dashboard with documentation
- Enhanced security with API key authentication
- Added WooCommerce cart and order support
- CORS support for cross-origin requests
- Better error handling and logging

### Version 1.0.0
- Initial release
- Basic REST API endpoints

## License

GPL v2 or later

## Credits

Developed by Fourlines Development for headless WordPress applications.
